import React from 'react';
import { Provider } from 'react-redux';
// import App from from './app';

const Root = (props) => {
    return (
        <Provider store={props.store} >
            {/* <App /> */} <h1>helloooo</h1>
        </ Provider>
    );
};

export default Root;