class GoalsController < ApplicationController
end
