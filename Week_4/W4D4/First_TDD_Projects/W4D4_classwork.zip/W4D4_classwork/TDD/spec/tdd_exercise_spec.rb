require 'rspec'
require 'tdd_exercise'

describe "#my_uniq" do
    it "returning a new array without duplicates" do
        arr = [1, 2, 1, 3, 3]
        expect(arr.my_uniq).to eq([1,2,3])
        expect(arr).to eq([1, 2, 1, 3, 3])
    end
end

describe "#two_sum" do 
    it " find all pairs of positions where the elements at those positions sum to zeroz" do 
        expect([-1, 0, 2, -2, 1].two_sum).to include([0,4],[2,3])
    end 

    it "is ordered from smaller index to bigger index" do 
        expect([-1, 0, 2, -2, 1].two_sum).to eq([[0, 4], [2, 3]])
    end 
end 

describe "#my_transpose" do 
    it "" do 
    end 
end 