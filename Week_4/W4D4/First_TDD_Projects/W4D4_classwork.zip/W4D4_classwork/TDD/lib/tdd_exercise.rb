class Array
    def my_uniq
        counter = Hash.new(0)
        new_arr = []
        self.each do |ele|
            if !counter.has_key?(ele)
                new_arr << ele
                counter[ele] += 1
            end
        end
        new_arr
    end

    def two_sum 
        pos = []
        (0...self.length-1).each do |idx_1|
            (idx_1+1..self.length-1).each do |idx_2|
                pos << [idx_1, idx_2] if self[idx_1]+self[idx_2] == 0
            end 
        end 
        pos 
    end 
end

