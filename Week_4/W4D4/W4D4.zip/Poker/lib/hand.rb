class Hand
end 