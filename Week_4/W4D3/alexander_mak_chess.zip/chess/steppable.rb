module Steppable
    def moves
        moves = []

        moves
    end

    private
    def move_diffs
        raise "move diffs should be from your piece!"
        king move diffs
        moves = [
            [-1,-1],
            [-1, 0],
            [-1, 1],
            [0 ,-1],
            [0 , 1],
            [1 ,-1],
            [1 , 0],
            [1 , 1]
        ]   
    end


end

