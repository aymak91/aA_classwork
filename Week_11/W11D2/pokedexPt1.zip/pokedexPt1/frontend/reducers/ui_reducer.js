
const uiReducer = (state = {}, action) {
  switch(action.type) {
    default:
      return state;
  }
}

export default uiReducer;